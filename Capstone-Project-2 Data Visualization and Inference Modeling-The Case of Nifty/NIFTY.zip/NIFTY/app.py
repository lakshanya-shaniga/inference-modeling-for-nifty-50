import os
import numpy as np
import pandas as pd
from flask import Flask, flash, request, redirect, url_for, render_template
from flask_cors import CORS
from werkzeug.utils import secure_filename
import pickle

app = Flask(__name__)
CORS(app)

month = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct','Nov', 'Dec']

with open('../elasticnet_reg.pkl', 'rb') as f:
    loaded_model = pickle.load(f)

@app.route('/', methods=['GET', 'POST'])
@app.route('/index', methods=['GET', 'POST'])
def home():
    return render_template("./index.html")

@app.route('/predict', methods=['GET', 'POST'])
def predict():
    
    input_values = []
    for i in month:
            input_values.append(request.form[i])
    input_data = pd.DataFrame([input_values], columns=month)
    predictions = loaded_model.predict(input_data)
    # return str(predictions[0])
    return render_template("./predict.html", ob1=str(predictions[0]))

if __name__=='__main__':
    app.run()